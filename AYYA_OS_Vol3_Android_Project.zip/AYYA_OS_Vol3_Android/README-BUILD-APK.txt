AYYA OS VOL. 3 — ANDROID APP PROJECT

This is a native Android WebView wrapper around your AYYA OS Vol. 3 app.
The app's HTML, CSS, JavaScript, initial goals, and local-first storage are bundled
inside the APK. No website hosting is required.

BUILD AN APK WITH ANDROID STUDIO
1. Install Android Studio (current stable) on a computer.
2. Open this folder as an existing project.
3. Let Android Studio sync Gradle and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be at:
   app/build/outputs/apk/debug/app-debug.apk
6. Transfer the APK to your Android phone and open it to install.
   Android may ask you to allow installs from that file manager/browser.

BUILD WITHOUT ANDROID STUDIO (GITHUB ACTIONS)
1. Create a new GitHub repository.
2. Upload all files and folders from this project into the repository root.
3. Open the Actions tab and enable workflows if prompted.
4. Run "Build AYYA OS APK" using Run workflow (or push to main).
5. Open the completed workflow run and download the
   "AYYA-OS-Vol3-debug-apk" artifact. Unzip it to get app-debug.apk.

APP DETAILS
- Package ID: com.ayyaos.vol3
- Minimum Android: 6.0 (API 23)
- Target Android: 15 (API 35)
- Offline: app content is bundled locally.
- Data: saved on the device in WebView local storage.
- Backup import: Android document picker.
- Backup export: Android Save As dialog.

NOTE
A debug APK is suitable for personal installation/testing. A Play Store release
requires a separately generated and securely stored signing key.
